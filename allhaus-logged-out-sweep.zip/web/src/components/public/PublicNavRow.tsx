'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { NAV_ROW_H } from '../workspace/NavRow'
import { ForallLockup } from '../brand/ForallLockup'
import { useAuth } from '../../stores/auth'

// =============================================================================
// PublicNavRow — the non-workspace nav row, and the only chrome outside the
// workspace.
//
// SUPERSEDES LandingNavRow AND Nav (the black topbar). The topbar was the last
// carrier of the retired marketing/auth register: black beam, white wordmark, a
// bare 21px crimson ∀ at the left, a mobile sheet of auth links. It survived on
// `/auth`, `/waitlist` and every share/SEO page while `/`, `/about` and
// `/admin` had already left it, so a visitor following a shared article link
// met one house and a visitor landing on `/` met another. One row now.
//
// MIRRORS NavRow + `ForallMenu anchor="row"`: same NAV_ROW_H, same
// `--ah-bone` ground, same lockup docked at the right end at disc 40 /
// wordmark 24.
//
// ─────────────────────────────────────────────────────────────────────────────
// IT SERVES MEMBERS TOO (added in tranche 2, correcting tranche 1).
//
// The first cut mounted this for logged-out visitors only, on the reasoning
// that a member has the workspace ∀. That was wrong, and the retired topbar had
// already got it right: it rendered a BARE WORDMARK BEAM for a logged-in member
// on any standalone route, because those routes exist outside the workspace and
// a member who lands on one — an invite link in their email, a subscription
// offer, a shared article — would otherwise have no navigation at all. Deleting
// the topbar deleted that, and tranche 2's pages are exactly the ones a member
// reaches by following a link from outside the app.
//
// So the row mounts for everyone off the workspace, and the LEFT END is what
// changes:
//   • logged out — the two destinations the topbar carried (CLOSED-BETA-ADR
//     §IV: log in, and the waiting list; there is no public signup), and each
//     page shows the one it is NOT. Offering "Log in" on the login page was the
//     retired register's habit and read as a mistake.
//   • logged in — nothing. The member's destinations all live behind the ∀ in
//     the workspace, so duplicating any of them here would be dead chrome, and
//     showing "Log in" to a member would be simply wrong. The lockup alone is
//     the whole row, exactly as the bare beam was.
//
// AND THE LOCKUP POINTS SOMEWHERE DIFFERENT. A visitor's home is `/`. A
// member's home is the workspace — sending them to the landing page, which
// HomeRedirect would immediately bounce, is a round trip through a page that
// exists to argue them into signing up for something they already have.
// ─────────────────────────────────────────────────────────────────────────────
//
// NO DIVIDER, for the same reason NavRow has none: the lockup docked at its end
// is indicator enough, a full-width rule is a heavier statement than the row is
// making, and the sitewide no-single-pixel-lines invariant forbids a thin one
// in its place outright.
//
// NO LIGHT ISLAND. Unlike PublicVessel this sits on the plain `--ah-bone`
// floor and wants the neutral slugs as html.dark leaves them — it inverts with
// the global toggle, exactly as NavRow and the mobile bar do.
//
// The floor never reaches behind it: LayoutShell publishes `--ah-row-band`
// (NAV_ROW_H + GRID) whenever this row is mounted, which fitted pages subtract
// from their height and scrolling pages add as bottom padding.
// =============================================================================

export function PublicNavRow() {
  const pathname = usePathname()
  const user = useAuth((s) => s.user)

  const onAuth = pathname.startsWith('/auth')
  const onWaitlist = pathname.startsWith('/waitlist')

  return (
    <div
      style={{
        position: 'fixed',
        left: 0,
        right: 0,
        bottom: 0,
        height: NAV_ROW_H,
        background: 'var(--ah-bone)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingLeft: 16,
        paddingRight: 16,
        // Above the Glasshouse scrim (z-55) and pane (z-56), below the lockup's
        // own layer (z-60) and the lightbox (z-70) — NavRow's z-order exactly.
        zIndex: 58,
      }}
      // Explain chrome: never dimmed, never annotatable. Mirrors NavRow.
      data-explain-chrome=""
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
        {!user && !onAuth && (
          <Link
            href="/auth?mode=login"
            className="label-ui text-grey-600 hover:text-black transition-colors"
          >
            Log in
          </Link>
        )}
        {!user && !onWaitlist && (
          // The register's ONLY accent button.
          //
          // `color` IS OVERRIDDEN, and this is a workaround for a SITEWIDE dark
          // bug, not a local preference. `.btn-accent` is `background:
          // var(--ah-crimson); color: var(--ah-white)`. Crimson is not a
          // DARK_SLUG so it holds at 181 36 42, but `--ah-white` IS one, and
          // html.dark takes it to 30 29 26 — so under dark mode every
          // `.btn-accent` in the app renders crimson with near-black text. It
          // needs the canonical light white regardless of mode. Fixing
          // `.btn-accent` in globals.css is the real repair and affects far more
          // than this row; until then, pin it here.
          <Link
            href="/waitlist"
            className="btn-accent btn-sm"
            style={{ color: 'rgb(255 255 255)' }}
          >
            Join the waiting list
          </Link>
        )}
      </div>

      <ForallLockup href={user ? '/reader' : '/'} />
    </div>
  )
}
