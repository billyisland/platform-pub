'use client'

import type { ReactNode } from 'react'

// =============================================================================
// PublicPage — the SCROLLING counterpart of PublicShell, for the standalone
// share/SEO surfaces.
//
// THESE PAGES HAVE NO VESSEL, ON PURPOSE. Everything else in the public
// register is content inside a ⊔. These are not: they are the reading
// experience itself — a shared article, a writer's profile, a tag. Putting a
// frame around an article puts a box around the one thing the site exists to
// deliver, and the frame would then have to scroll internally, which is exactly
// the wrong behaviour for a long read. So: bone floor, the page's own body,
// ordinary page scroll.
//
// WHICH MEANS THE ROW BAND WORKS THE OPPOSITE WAY ROUND HERE. A fitted page
// (PublicShell) SUBTRACTS `--ah-row-band` from its height so the vessel sits
// clear of the nav row. A scrolling page ADDS it as bottom padding so its last
// line clears the row. Both read the same variable; neither could use the
// other's rule. `minHeight` is `calc(100dvh - band)` so that short content plus
// the padding comes to exactly one viewport and doesn't invent a scrollbar —
// `main` is already `min-height: 100dvh`, so a second full-height child plus
// padding would overflow by the height of the band.
//
// `ground` IS OPTIONAL because some of these surfaces bring their own.
// ArticleReader's root is `min-h-screen bg-white` — it is a reading surface and
// owns its ground. Painting bone behind it would be a layer nobody sees, and
// `min-h-screen` inside a `calc(100dvh - band)` parent would push the page past
// the fold for no reason. Pass `ground={false}` and let the child do it.
//
// WHAT THIS COMPONENT MUST NOT DO IS TOUCH THE BODIES. Every one of these
// routes renders a component that is ALSO mounted inside a workspace overlay —
// ArticleReader in ReaderOverlay, TagBrowser and SourceSurface in
// SurfaceOverlay, AuthorProfileView and WriterActivity in ProfileOverlay. They
// are one component serving two registers, which is the right architecture (the
// share view and the overlay view should not drift), and it means any retired
// styling inside them is a WORKSPACE question, not a logged-out one. Restyling
// them from here would silently redesign the member surface. See §VII of the
// sweep doc for the audit.
// =============================================================================

interface PublicPageProps {
  children: ReactNode
  /** Paint the bone floor. Pass false when the child supplies its own ground. */
  ground?: boolean
  /** Centre the body at a pixel measure. Omit for full-bleed. */
  measure?: number
}

export function PublicPage({
  children,
  ground = true,
  measure,
}: PublicPageProps) {
  return (
    <div
      style={{
        background: ground ? 'var(--ah-bone)' : undefined,
        minHeight: 'calc(100dvh - var(--ah-row-band, 0px))',
        paddingBottom: 'var(--ah-row-band, 0px)',
      }}
    >
      {measure ? (
        <div style={{ maxWidth: measure, margin: '0 auto', width: '100%' }}>
          {children}
        </div>
      ) : (
        children
      )}
    </div>
  )
}
