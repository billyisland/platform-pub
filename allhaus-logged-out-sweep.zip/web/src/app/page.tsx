import type { Metadata } from 'next'
import HomeRedirect from '../components/layout/HomeRedirect'
import { LandingVessel } from '../components/landing/LandingVessel'
import { PublicShell } from '../components/public/PublicShell'

const TITLE = 'all.haus — No one should own the public square.'
const DESCRIPTION =
  'A writing platform on Nostr: omnivorous feeds sorted by rules you set, and a few pence to whoever wrote the thing.'

export const metadata: Metadata = {
  title: TITLE,
  description: DESCRIPTION,
  openGraph: {
    title: TITLE,
    description: DESCRIPTION,
    type: 'website',
    siteName: 'all.haus',
  },
  twitter: {
    card: 'summary',
    title: TITLE,
    description: DESCRIPTION,
  },
}

const HEADLINE =
  'all.haus is a writing platform dedicated to three radical propositions:'

const PROPOSITIONS = [
  'No one should own the public square.',
  'Keeping up shouldn’t mean being farmed.',
  'Writing is work and deserves to be paid as such.',
]

const PROSE = [
  'Build omnivorous feeds that pull the whole open social web — Bluesky, Mastodon, Substack, plain old RSS — into one place. Sort them with rules you set rather than rules set on you. No dopamine hacks, no algorithm optimised for pointless, endless engagement. A feed is a tool: you need the right one for each job. At all.haus you can create as many as you like.',
  'Read what’s worth reading and pay a few pence for it. No subscription, no bundle, no commitment you’ll forget to cancel. The money goes to whoever wrote the piece, and they set the terms.',
  'The whole thing runs on Nostr: an open protocol with no company behind it, no servers to seize, and no owner to sell it to someone worse.',
]

// CHANGED 2026-07-25 (logged-out sweep). This page used to hand-roll what is
// now the shared public chassis: its own bone floor, its own 720 measure, its
// own `NAV_ROW_H + GRID` bottom padding, and its own `<LandingNavRow />`. All
// four moved out — the floor and measure into PublicShell, the row and the
// reserved band into LayoutShell, which now mounts one row for every
// logged-out visitor on every route. LandingNavRow is deleted; PublicNavRow is
// its generalisation.
//
// WHAT DID NOT MOVE: LandingVessel. `/` keeps the DOUBLED wall (wall / 8px
// buffer / wall) while every other public page uses PublicVessel's single wall.
// That asymmetry is deliberate and documented in both files — the doubling is
// an argument about the lattice, worth a frame's weight on the one page whose
// job is to state the house's terms, and not worth it around a login form.
export default function HomePage() {
  return (
    <PublicShell measure="prose">
      <HomeRedirect />
      <LandingVessel
        headline={HEADLINE}
        propositions={PROPOSITIONS}
        prose={PROSE}
      />
    </PublicShell>
  )
}
