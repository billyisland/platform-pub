# Tranche 3 — patches for the four routes I haven't rewritten in full

I only read the render bodies of these files, not their metadata and data-fetching
halves, so rewriting them whole would mean reconstructing code I haven't seen.
Each change is two or three lines. Full rewrites are supplied for
`/source/[id]` and `/author/[authorId]`, which are short enough that I read all
of them.

Every one of these is **wrapper-only**. The bodies delegate to components that
are also mounted inside workspace overlays — see the note in `PublicPage.tsx`.

---

## 1. `/read/[postId]` — and a real bug

**`bg-grey-50` does not exist.** The Tailwind theme defines `grey` at
100/200/300/400/600 only (`tailwind.config.js`), so this class has always
resolved to nothing: the page has had no background, and the white reading
column has been floating on the browser default. The `shadow-sm` was doing the
work the missing ground should have done.

Add the import:

```tsx
import { PublicPage } from '../../../components/public/PublicPage'
```

Replace:

```tsx
    <div className="min-h-screen bg-grey-50 py-8">
      <WorkspacePaneRedirect overlay="reader" params={{ read: params.postId }} />
      <div
        className="mx-auto w-full bg-white shadow-sm"
        style={{ maxWidth: 640 }}
      >
```

with:

```tsx
    <PublicPage>
      <WorkspacePaneRedirect overlay="reader" params={{ read: params.postId }} />
      {/* The reading column sits on the bone floor with no shadow. The house has
          no elevation: a card is distinguished from its ground by being a
          different colour, which is what every card in the workspace does. The
          shadow was compensating for `bg-grey-50` never existing. */}
      <div
        className="mx-auto w-full"
        style={{ maxWidth: 640, background: 'var(--ah-white)', marginTop: 32 }}
      >
```

…and close with `</PublicPage>` in place of the outer `</div>`.

---

## 2. `/article/[dTag]` — wrap with `ground={false}`

`ArticleReader`'s root is `min-h-screen bg-white`: it is a reading surface and
owns its ground. Painting bone behind it would be a layer nobody sees, and
`min-h-screen` inside a `calc(100dvh - band)` parent would push the page past
the fold for nothing.

Add the import, then replace the fragment wrapper:

```tsx
    <>
    <WorkspacePaneRedirect overlay="reader" params={{ article: params.dTag }} />
```

with:

```tsx
    <PublicPage ground={false}>
    <WorkspacePaneRedirect overlay="reader" params={{ article: params.dTag }} />
```

…and close with `</PublicPage>` in place of `</>`.

---

## 3. `/tag/[tag]` — wrap

Same two-line change: `<>` → `<PublicPage>`, `</>` → `</PublicPage>`, plus the
import. `TagBrowser` is untouched (SurfaceOverlay mounts it too).

---

## 4. `/[username]` — wrap, plus two type corrections

Replace:

```tsx
    <div className="mx-auto max-w-article-frame px-4 sm:px-6 py-12">
```

with:

```tsx
    <PublicPage>
      <div className="mx-auto max-w-article-frame px-4 sm:px-6 py-12">
```

…closing with `</PublicPage>` after the existing `</div>`.

### Then two things inside it that are the register's own drift, not the workspace's

This page's header is written inline here rather than in a shared component, so
it *is* in scope.

**`font-light` on the h1.** The house's serif display weight is `font-medium`
everywhere else — `/`, `/about`, every card title, `PublicTitle`. A light serif
at 3xl–4xl is a fourth weight the type scale doesn't have.

```diff
-              className="font-serif text-3xl sm:text-4xl font-light text-black"
+              className="font-serif text-3xl sm:text-4xl font-medium text-black"
```

**`text-grey-300` on the metadata lines.** `grey-300` is `185 183 175` — used
for disabled states and placeholder washes elsewhere. It is carrying the
`@username`, the article and follower counts, and the RSS link, which are facts,
not hints. The equivalent role in the vessel palette is `cardMeta`
(`stone-400`, `138 136 128`); `grey-600` is the nearest neutral slug.

```diff
-            <p className="text-ui-xs text-grey-300 mt-0.5">@{params.username}</p>
+            <p className="text-ui-xs text-grey-600 mt-0.5">@{params.username}</p>
```

…and the same substitution on the counts paragraph and the RSS anchor (three
further occurrences of `text-grey-300` in that block).

This one is a judgement call rather than a rule — if you meant those to
recede, leave them. But at `text-ui-xs` on white, `grey-300` is close to the
AA floor.
