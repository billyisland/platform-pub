# all.haus landing page — screengrabs → live markup

## New files

    web/src/components/landing/demos/primitives.tsx
    web/src/components/landing/demos/WorkspaceDemo.tsx
    web/src/components/landing/demos/OmnivoreDemo.tsx
    web/src/components/landing/demos/GateDemo.tsx
    web/src/components/landing/LandingFigure.tsx

## Rewritten

    web/src/components/landing/LandingVessel.tsx
    web/src/app/page.tsx

## Delete

    web/public/landing/workspace.webp
    web/public/landing/omnivore.webp
    web/public/landing/reader.webp
    web/public/landing/            (directory now empty)

And, inside the rewritten files, these are gone: the `Shot` interface,
`SHOT_RATIO`, `LandingShot`, its `failed` state and disc placeholder, and the
`next/image` import from LandingVessel.

## Paste by hand

`patches/globals-1d.css` goes into `web/src/app/globals.css`, inside
`@layer components`, directly after the §1c block and before §2
(`.ah-vessel-scroll`).

## Copy

The three prose paragraphs are UNCHANGED, in their original order: feeds,
payment, protocol. `FIGURES` in page.tsx is ordered to match, so each demo
follows the paragraph it illustrates. The Nostr paragraph has no demo.

Captions are as before, except the gate's, which gained a clause:
"Read it — pay a few pence. No subscription required." The old caption stopped
at "pay a few pence", which left the demo's Subscribe button looking like a
contradiction of it.

## Checks worth running

- `npm run build` — `Figure` is exported as a type from LandingVessel and
  imported by page.tsx; if the repo's lint config enforces `import type`
  separation this may want splitting.
- Dark toggle on `/`. The demos read `paletteFor(…, useResolvedDark())` through
  LandingVessel, inside LIGHT_ISLAND_STYLE. This is the same pairing Vessel.tsx
  uses, but it is the one thing here most likely to be subtly wrong.
- 390px viewport: gate inset should be gone, workspace should show two columns.
- `knip` — three .webp deletions and several removed exports.
