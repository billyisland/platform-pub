# all.haus landing page — screengrabs → live markup (v2)

## New files

    web/src/components/landing/demos/primitives.tsx
    web/src/components/landing/demos/CanvasDemo.tsx      ← was WorkspaceDemo
    web/src/components/landing/demos/OmnivoreDemo.tsx
    web/src/components/landing/demos/ReaderDemo.tsx      ← was GateDemo
    web/src/components/landing/LandingFigure.tsx

## Rewritten

    web/src/components/landing/LandingVessel.tsx
    web/src/app/page.tsx

## Delete

    web/public/landing/workspace.webp
    web/public/landing/omnivore.webp
    web/public/landing/reader.webp
    web/public/landing/            (directory now empty)

Gone inside the rewritten files: `Shot`, `SHOT_RATIO`, `LandingShot`, its
`failed` state and disc placeholder, and the `next/image` import.

## Paste by hand

`patches/globals-1d.css` → `web/src/app/globals.css`, inside `@layer
components`, after §1c and before §2 (`.ah-vessel-scroll`).

The demos will look broken without it — §1d owns their geometry, not just
their sizing. That is deliberate (see below) but it does mean the CSS is not
optional polish.

## What changed since v1

**The workspace demo became the canvas demo.** Three equal columns showed the
weakest reading of the claim. Now four feeds, irregular: one wide and tall
down the left, two narrow stacked in the right column, one horizontal along
the bottom with cards running off its own edge under a gradient. Four
colourways — basic, spring, winter, autumn.

**It scales instead of reflowing.** This is the mobile fix. The v1 version
dropped to two columns under a viewport media query and got knocked about,
because it was sized against a guess at the viewport rather than the width it
was handed. Now the wrapper is a container and the base size is
`clamp(8.5px, 1.95cqw, 12px)`. Below 430px of *container* width the card
bodies and tags hide, leaving bylines and titles — shed detail, don't shrink.

The arrangement never changes at any width. It's the argument; a mobile
version that tidies the feeds into a regular stack demonstrates the opposite.

**The gate demo became the reader demo.** It now shows the whole Glasshouse
figure — blurred four-feed floor, scrim at `.gh-scrim`'s wash, lifted pane
with grip and ✕, article and gate inside. The old inset is gone: a lifted pane
over a blurred field can't be mistaken for the page's own prose, so the inset
was no longer doing separate work.

**Captions changed.** The canvas one is new: "Feeds are objects on a canvas —
size them, stack them, turn them sideways". Both `description` strings
rewritten to match what's now shown.

**`DemoVessel` has two geometry modes.** Pass `wall` and it draws its own ⊔
inline; omit it and it only publishes `--ah-demo-wall` and leaves border /
padding / gap to §1d. The second mode exists because inline styles beat
`@layer components` — an inline zeroed border would silently flatten the ⊔.

## Copy

Prose paragraphs unchanged and in the original order: feeds, payment,
protocol. `FIGURES` follows that order.

## Checks worth running

- **Container query support.** `container-type: inline-size` and `cqw` are the
  one genuinely new thing here. Fine in current browsers; if the repo's
  browserslist reaches back further than you think, this is what will break.
  Fallback would be a fixed 11px base — legible, just not fluid.
- **Dark toggle on `/`.** Four seasonal palettes now resolve inside
  `LIGHT_ISLAND_STYLE` (canvas: basic/spring/winter/autumn; reader floor:
  basic/summer/autumn/spring). Still the likeliest thing to be subtly wrong.
- **`--ah-demo-pane` and `--ah-demo-floor`** are set inline as custom
  properties via a `['--x' as string]` cast. If the repo has a stricter
  pattern for that, worth matching it.
- 390px viewport: canvas keeps its arrangement, loses card bodies; reader
  pane keeps a visible margin.
- `knip` — three `.webp` deletions and several removed exports.
